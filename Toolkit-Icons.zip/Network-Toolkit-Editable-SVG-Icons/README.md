# Network Toolkit — editable SVG icon pack

**92 standalone SVG files:** 78 UI vector variants, 2 brand masters (same design), and 12 clearly labeled CSS-to-vector shape conversions. The UI registry contains 68 names, deduplicated to 67 SVGs; `right` and `arrowRight` share one exact design. Additional component-specific paths and styled/rotated states are included.

## Start here

Open `index.html` in a browser for the complete visual index, or `preview-contact-sheet.png` for a ready-rendered contact sheet. Open any `.svg` in Illustrator, Inkscape, Figma or a text editor. All artwork is editable vector geometry—not a PNG embedded in an SVG. No fonts are needed by the exported SVGs. Filenames describe the icon's purpose; `inventory.csv`, `inventory.json` and `usage-map.csv` map them to source symbols and UI locations.

## Editing

- Most UI icons retain the original `viewBox="0 0 24 24"`, `fill="none"`, 1.7-unit stroke and round caps/joins. Change the root `color` to recolor the `currentColor` stroke. The supplied neutral default is `#182638` so every SVG opens legibly on a white editor canvas. The app itself inherits context/theme colors.
- Panel controls and input-clear retain their actual 1.8-unit stroke. Saved-session badges retain their 16×16 viewBox, 1.5-unit stroke and dark/light default fills. Their colors are resolved from the app's theme variables so they work standalone.
- `brand/network-toolkit-app-icon.svg` is the exact checked-in runtime master, byte for byte. `brand/network-toolkit-layered-editor-master.svg` retains the original drawing geometry, groups, palette and original layer/shape labels. Its external DTD, non-rendered foreignObject and opaque Illustrator embedded state were omitted for safe interchange. It is not claimed to be the untouched raw Illustrator export; that remains at the recorded repository source path. No brand artwork was redrawn.
- CSS-derived assets are explicitly separate: deterministic circles, status overlays and grip shapes translated from CSS dimensions, not claimed as original SVG source. Runtime animation, positioning and high-contrast overrides are not baked in.
- Paths are not outlined/flattened, so you can still edit stroke weight and nodes. An editor may flatten groups on import; retain the original files as masters.

## Exact source baseline

Extracted read-only on 2026-10-28 from the **1.17.110 review candidate**, remote commit prefix `8f719374`, tree `78b514a491d7527c6c3f71ba1694663f212f7b84`. The verified equivalent local commit is `4d07ff22d1bad51c0f9354909213c6d63798c783`. This is not a new app build or release.

Compared with published **1.17.109**, commit `d3494a879604fb2523e0867ad1fb175a2f9abbf5`, tree `9dda3650d5c794a4fc1c734976619819ce87fbfa` (equivalent local commit `848cb3d984babbd99a648f7c5372fd507e20e711`). The 68-name central icon registry and the listed component SVG sources are unchanged. Full file-hash comparison is in `baseline-comparison.json`; source files that changed for unrelated behavior are not falsely labeled identical.

## Coverage and honest limits

The audit covers all tracked SVG/raster/font asset extensions and the app's own HTML, CSS, JavaScript and native icon loading. It includes the main icon path registry, tool/sidebar/navigation/action/status icons, printer glyph, copy variants, panel directions, session chevrons, saved-session bookmarks, input-clear and brand assets.

`NON-VECTOR-AND-DYNAMIC-SYMBOLS.md` inventories symbols implemented with text/Unicode, CSS and OS rendering. Those are not secretly traced or substituted with an invented icon. The Unicode glyphs cannot be exported as exact portable path outlines without the user's actual rendering font and its permission. Their source characters and locations are supplied instead. Real-time charts, data-dependent document diff maps, native system controls and arbitrary terminal/device output are not fixed app icons.

The existing PNG and multi-resolution ICO are derived outputs of the supplied brand vector; no raster tracing is required. No other bundled image icon or icon font file was found.

## Inventory and deduplication

`inventory.csv/json` lists every exported variant, original geometry/style source, viewBox, colors and checksum. `usage-map.csv` contains 410 static resolver/property/navigation references; dynamic calls also reuse those same registry names. It is a source map, not a claim that every runtime branch was exercised. Exact registry duplicates and the two rounded-copy inline declarations are deduplicated; intentional style/state variants remain separate.

`source-audit.json` lists all SVG-generation sites and image/font asset files so data-driven graphics are accounted for rather than silently omitted. `validation.json` records XML, external-resource and render checks. `SHA256SUMS.txt` verifies packaged file integrity.

## Ownership and safety

See `LICENSE-NOTICE.txt` and the preserved `THIRD_PARTY_NOTICES.txt`. This private export grants no new redistribution rights. SVGs contain no scripts, external links/resources, foreignObject, DTD, raster image or font dependencies. The index is offline-only and contains no scripts. No user configurations, credentials, screenshots of the app or device results are packaged. The repository, release artifacts and access settings were not changed.
